package com.saint.game.launcher;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.saint.game.BuildConfig;
import com.saint.game.R;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.saint.game.core.Utils;
import com.tuyenmonkey.mkloader.model.Line;

import static android.widget.Toast.LENGTH_LONG;
import static com.saint.game.core.Config.APP_PATH;
import static com.saint.game.core.Config.GAME_PATH;
import static com.saint.game.core.Config.PATH_DOWNLOADS;
import static com.saint.game.core.Config.URL_CLIENT;
import static com.saint.game.core.Config.URL_FILES;
import static com.saint.game.core.Config.URL_FILES_UPDATE;

public class InstallGame extends AppCompatActivity {
    private TextView loading;
    private ProgressBar progressloading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_install);
        initialize(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                    || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
            } else {
                InstallGame(Utils.getType());
            }
        } else {
            InstallGame(Utils.getType());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) {
                granted &= result == PackageManager.PERMISSION_GRANTED;
            }
            if (granted) {
                InstallGame(Utils.getType());
            } else {
                showMessage("Нужно разрешение на доступ к файлам игры. Разреши его в настройках приложения.");
                finish();
            }
        }
    }

    public static void writeFile(String path, String str) {
        File file = new File(path);

        try {
            if (!file.exists())
                file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileWriter fileWriter = null;

        try {
            fileWriter = new FileWriter(new File(path), false);
            fileWriter.write(str);
            fileWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fileWriter != null)
                    fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void writeLog(Exception e){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String text = sw.toString();
        writeFile(APP_PATH+"/log.txt", text);
    }

    private void StartGame()
    {
        Intent intent = new Intent(this, com.saint.game.core.GTASA.class);
        intent.putExtras(getIntent());
        startActivity(intent);
        finish();
    }

    @Override
    public void onStop ()
    {
        //  mediaPlayer.stop();
        super.onStop();
    }

    private void InstallGame(int type)
    {
        switch (type) {
            case 0:
            {
                File dir = new File(PATH_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                final DownloadTask downloadTask = new DownloadTask(this);
                downloadTask.execute(URL_FILES);
                break;
            }
            case 1:
            {
                // Install UPDATE APK
                File dir = new File(PATH_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                final DownloadTask downloadTask = new DownloadTask(this);
                downloadTask.execute(URL_CLIENT);
                break;
            }
            case 2:
            {
                File dir = new File(PATH_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                final DownloadTask downloadTask = new DownloadTask(this);
                downloadTask.execute(URL_FILES_UPDATE);
                break;
            }
        }
    }

    private void initialize(Bundle savedInstanceState) {
        loading = (TextView) findViewById(R.id.downloadinfo);
        progressloading = (ProgressBar) findViewById(R.id.downloadingfiles);
    }


    public void UnZipZip()
    {
        final UnZipTask unzipTask = new UnZipTask(this);
        if(Utils.getType() == 0) unzipTask.execute(PATH_DOWNLOADS+"game.zip", GAME_PATH);
        else unzipTask.execute(PATH_DOWNLOADS+"upd.zip", GAME_PATH);
    }

    private void InstallAPK(final String apkname) {
        try {
            File file = new File(PATH_DOWNLOADS, apkname + ".apk");
            Intent intent;
            if (file.exists()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    Uri apkUri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", file);
                    intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                    intent.setData(apkUri);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } else {
                    Uri apkUri = Uri.fromFile(file);
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                startActivity(intent);
                finish();
            }
            else showMessage("Ошибка установки: файл не найден");
        } catch (Exception e) {
            Log.e("InstallAPK", "Ошибка установки:" + e.getMessage());
            writeLog(e);
        }
    }

    public void showMessage(String _s) {
        Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_LONG).show();
    }

    private class DownloadTask extends AsyncTask<String, Integer, String> {

        private Context context;
        private PowerManager.WakeLock mWakeLock;

        public DownloadTask(Context context) {
            this.context = context;
        }

        @Override
        protected String doInBackground(String... sUrl) { // doInAnal
            InputStream input = null;
            OutputStream output = null;
            HttpURLConnection connection = null;
            try {
                URL url = new URL(sUrl[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    return "Server returned HTTP " + connection.getResponseCode()
                            + " " + connection.getResponseMessage();
                }
                int fileLength = connection.getContentLength();
                input = connection.getInputStream();
                if(Utils.getType() == 0) {
                    File file = new File(PATH_DOWNLOADS, "game.zip");
                    if (file.exists()) file.delete();
                    output = new FileOutputStream(PATH_DOWNLOADS + "game.zip");
                }
                else if(Utils.getType() == 1) {
                    File file = new File(PATH_DOWNLOADS, "launcher.apk");
                    if (file.exists()) file.delete();
                    output = new FileOutputStream(PATH_DOWNLOADS + "launcher.apk");
                }
                else if(Utils.getType() == 2) {
                    File file = new File(PATH_DOWNLOADS, "upd.zip");
                    if (file.exists()) file.delete();
                    output = new FileOutputStream(PATH_DOWNLOADS + "upd.zip");
                }
                byte data[] = new byte[4096];
                long total = 0;
                int count;
                while ((count = input.read(data)) != -1) {
                    if (isCancelled()) {
                        input.close();
                        return null;
                    }
                    total += count;
                    if (fileLength > 0)
                        publishProgress((int) (total * 100 / fileLength));
                    output.write(data, 0, count);
                }
            } catch (Exception e) {
                return e.toString();
            } finally {
                try {
                    if (output != null)
                        output.close();
                    if (input != null)
                        input.close();
                } catch (IOException ignored) {
                }

                if (connection != null)
                    connection.disconnect();
            }
            return null;
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
            mWakeLock.acquire();
            progressloading.setVisibility(View.VISIBLE);
            progressloading.setIndeterminate(false);
            progressloading.setMax(100);
        }

        @Override
        protected void onProgressUpdate(Integer... progress)
        {
            super.onProgressUpdate(progress);
            if(Utils.getType() == 0) loading.setText("Идет загрузка кеша (byDmitry_Komarov)...                  "+progress[0] + "%");
            if(Utils.getType() == 1) loading.setText("Идет загрузка лаунчера (byDmitry_Komarov)...               "+progress[0] + "%");
            if(Utils.getType() == 2) loading.setText("Идет загрузка доп.файлов (byDmitry_Komarov)...            "+progress[0] + "%");
            progressloading.setProgress(progress[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            mWakeLock.release();
            loading.setVisibility(View.INVISIBLE);
            progressloading.setVisibility(View.INVISIBLE);
            if (Utils.getType() == 0 || Utils.getType() == 2) {
                if (result != null) {
                    Toast.makeText(context, "Ошибка загрузки: " + result, LENGTH_LONG).show();
                    Log.e("BlackStarRP", "Game files download failed: " + result);
                    return;
                }
                Toast.makeText(context, "Файлы загружены. Распаковка...", Toast.LENGTH_SHORT).show();
                UnZipZip();
            }
            if(Utils.getType() == 1)
            {
                showMessage("Подтвердите установку");
                InstallAPK("launcher");
            }
        }
    }

    private class UnZipTask extends AsyncTask <String, Integer, String> {
        private Context context;

        public UnZipTask(Context context) {
            this.context = context;
        }
        @Override
        protected String doInBackground(String... params) {
            File zipFile = new File(params[0]);
            File destination = new File(params[1]);
            if (!zipFile.isFile() || zipFile.length() == 0) {
                return "Архив не найден или пуст: " + zipFile.getAbsolutePath();
            }
            if (!destination.exists() && !destination.mkdirs()) {
                return "Не удалось создать папку игры: " + destination.getAbsolutePath();
            }
            try (java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(
                    new java.io.BufferedInputStream(new java.io.FileInputStream(zipFile)))) {
                java.util.zip.ZipEntry entry;
                byte[] buffer = new byte[16 * 1024];
                while ((entry = zin.getNextEntry()) != null) {
                    File out = new File(destination, entry.getName());
                    String root = destination.getCanonicalPath() + File.separator;
                    String canonical = out.getCanonicalPath();
                    if (!canonical.equals(destination.getCanonicalPath()) && !canonical.startsWith(root)) {
                        return "Небезопасный путь в архиве: " + entry.getName();
                    }
                    if (entry.isDirectory()) {
                        if (!out.isDirectory() && !out.mkdirs()) {
                            return "Не удалось создать папку: " + out.getAbsolutePath();
                        }
                    } else {
                        File parent = out.getParentFile();
                        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
                            return "Не удалось создать папку: " + parent.getAbsolutePath();
                        }
                        try (java.io.BufferedOutputStream output = new java.io.BufferedOutputStream(
                                new java.io.FileOutputStream(out))) {
                            int count;
                            while ((count = zin.read(buffer)) != -1) {
                                output.write(buffer, 0, count);
                            }
                        }
                    }
                    zin.closeEntry();
                }
            } catch (Exception e) {
                Log.e("BlackStarRP", "Game archive extraction failed", e);
                writeLog(e instanceof Exception ? (Exception)e : new Exception(e));
                return "Ошибка распаковки: " + e.getMessage();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading.setVisibility(View.VISIBLE);
            progressloading.setVisibility(View.VISIBLE);
            progressloading.setIndeterminate(false);
            progressloading.setMax(100);
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            super.onProgressUpdate(progress);
            loading.setText("Идет распаковка файлов...");
            progressloading.setProgress(progress[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            loading.setVisibility(View.INVISIBLE);
            progressloading.setVisibility(View.INVISIBLE);
            if (result != null) {
                Toast.makeText(context, result, LENGTH_LONG).show();
                Log.e("BlackStarRP", result);
                return;
            }
            File requiredGameFile = new File(GAME_PATH, "texdb/gta3.img");
            if (!requiredGameFile.isFile() || requiredGameFile.length() == 0) {
                Toast.makeText(context, "Архив распакован, но texdb/gta3.img не найден. Проверь архив игры.", LENGTH_LONG).show();
                Log.e("BlackStarRP", "Required game file missing: " + requiredGameFile.getAbsolutePath());
                return;
            }
            Toast.makeText(context, "Файлы распакованы. Запускаю игру...", Toast.LENGTH_SHORT).show();
            StartGame();
        }

        private void mkdirs(java.io.File outdir, String path)
        {
            java.io.File d = new java.io.File(outdir, path);
            if(!d.exists())
                d.mkdirs();
        }

        private String dirpart(String name)
        {
            int s = name.lastIndexOf(java.io.File.separatorChar);
            return s == -1 ? null : name.substring(0, s);
        }
    }
}
