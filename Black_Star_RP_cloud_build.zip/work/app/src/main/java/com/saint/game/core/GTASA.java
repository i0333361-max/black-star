package com.saint.game.core;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import com.wardrumstudios.utils.WarMedia;

public class GTASA extends WarMedia {
    public static GTASA gtasaSelf = null;
    static String vmVersion;
    private boolean once = false;

    static {
        vmVersion = null;
        System.out.println("**** Loading SO's");
        CrashLogger.log("GTASA class initialization started");
        try
        {
            vmVersion = System.getProperty("java.vm.version");
            System.out.println("vmVersion " + vmVersion);
            CrashLogger.log("Loading native library ImmEmulatorJ");
            System.loadLibrary("ImmEmulatorJ");
            CrashLogger.log("ImmEmulatorJ loaded");
        } catch (ExceptionInInitializerError | UnsatisfiedLinkError e) {
            CrashLogger.logException("ImmEmulatorJ load failed (continuing as before)", e);
        }

        try {
            CrashLogger.log("Loading native library GTASA");
            System.loadLibrary("GTASA");
            CrashLogger.log("GTASA native library loaded");
        } catch (UnsatisfiedLinkError e) {
            CrashLogger.logException("FATAL: failed to load GTASA native library", e);
            throw e;
        }
        try {
            CrashLogger.log("Loading native library samp");
            System.loadLibrary("samp");
            CrashLogger.log("samp native library loaded");
        } catch (UnsatisfiedLinkError e) {
            CrashLogger.logException("FATAL: failed to load samp native library", e);
            throw e;
        }
    }

    public static void staticEnterSocialClub()
    {
        gtasaSelf.EnterSocialClub();
    }

    public static void staticExitSocialClub() {
        gtasaSelf.ExitSocialClub();
    }

    public void AfterDownloadFunction() {

    }

    public void EnterSocialClub() {

    }

    public void ExitSocialClub() {

    }

    public boolean ServiceAppCommand(String str, String str2)
    {
        return false;
    }

    public int ServiceAppCommandValue(String str, String str2)
    {
        return 0;
    }

    public native void main();

    public void onActivityResult(int i, int i2, Intent intent)
    {
        super.onActivityResult(i, i2, intent);
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    public void onCreate(Bundle bundle)
    {
        if(!once)
        {
            once = true;
        }

        CrashLogger.log("GTASA onCreate entered");
        System.out.println("GTASA onCreate");
        gtasaSelf = this;
        wantsMultitouch = true;
        wantsAccelerometer = true;
        try {
            super.onCreate(bundle);
            CrashLogger.log("GTASA super.onCreate returned; native engine may now initialize");
        } catch (RuntimeException e) {
            CrashLogger.logException("Exception during GTASA onCreate", e);
            throw e;
        }
    }

    public void onDestroy()
    {
        System.out.println("GTASA onDestroy");
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent)
    {
        return super.onKeyDown(i, keyEvent);
    }

    public void onPause()
    {
        System.out.println("GTASA onPause");
        super.onPause();
    }

    public void onRestart()
    {
        System.out.println("GTASA onRestart");
        super.onRestart();
    }

    public void onResume()
    {
        CrashLogger.log("GTASA onResume: entering superclass");
        System.out.println("GTASA onResume");
        super.onResume();
        CrashLogger.log("GTASA onResume: superclass returned");
    }

    public void onStart()
    {
        CrashLogger.log("GTASA onStart: entering superclass");
        System.out.println("GTASA onStart");
        super.onStart();
        CrashLogger.log("GTASA onStart: superclass returned");
    }

    public void onStop()
    {
        System.out.println("GTASA onStop");
        super.onStop();
    }

    public native void setCurrentScreenSize(int i, int i2);
}