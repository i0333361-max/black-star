package com.saint.game.core;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Writes a persistent diagnostic log before and during game startup. */
public final class CrashLogger {
    private static final String TAG = "BlackStarCrash";
    private static final Object LOCK = new Object();
    private static volatile File logFile;
    private static boolean handlerInstalled = false;

    private CrashLogger() { }

    public static void install(Context context) {
        synchronized (LOCK) {
            logFile = chooseLogFile(context.getApplicationContext());
            append("\n========== BLACK STAR RP DIAGNOSTIC LOG ==========");
            append("Device=" + Build.MANUFACTURER + " " + Build.MODEL);
            append("Android=" + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
            append("App package=" + context.getPackageName());
            append("Log file=" + (logFile == null ? "unavailable" : logFile.getAbsolutePath()));
            if (!handlerInstalled) {
                final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
                Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                    @Override public void uncaughtException(Thread thread, Throwable error) {
                        logException("UNCAUGHT JAVA EXCEPTION on thread " + thread.getName(), error);
                        if (previous != null) previous.uncaughtException(thread, error);
                    }
                });
                handlerInstalled = true;
            }
        }
    }

    private static File chooseLogFile(Context context) {
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File folder = new File(downloads, "BlackStarRP");
        if ((folder.isDirectory() || folder.mkdirs()) && folder.canWrite()) {
            File file = new File(folder, "launcher-log.txt");
            if (file.exists() ? file.canWrite() : canCreate(file)) return file;
        }
        File external = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (external != null) {
            File file = new File(external, "launcher-log.txt");
            if (file.exists() ? file.canWrite() : canCreate(file)) return file;
        }
        File file = new File(context.getFilesDir(), "launcher-log.txt");
        return (file.exists() ? file.canWrite() : canCreate(file)) ? file : null;
    }

    private static boolean canCreate(File file) {
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return false;
            FileOutputStream stream = new FileOutputStream(file, true);
            stream.close();
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Cannot create diagnostic log", e);
            return false;
        }
    }

    public static void log(String message) {
        append(message);
    }

    public static void logException(String message, Throwable error) {
        append(message);
        if (error != null) {
            StringWriter buffer = new StringWriter();
            error.printStackTrace(new PrintWriter(buffer));
            append(buffer.toString());
        }
    }

    public static String getLogPath() {
        File file = logFile;
        return file == null ? "путь к файлу недоступен" : file.getAbsolutePath();
    }

    private static void append(String message) {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = time + " | " + String.valueOf(message) + "\n";
        Log.i(TAG, String.valueOf(message));
        synchronized (LOCK) {
            File file = logFile;
            if (file == null) return;
            try {
                FileOutputStream stream = new FileOutputStream(file, true);
                OutputStreamWriter writer = new OutputStreamWriter(stream, "UTF-8");
                writer.write(line);
                writer.flush();
                writer.close();
            } catch (Exception e) {
                Log.e(TAG, "Failed to write diagnostic log", e);
            }
        }
    }
}
