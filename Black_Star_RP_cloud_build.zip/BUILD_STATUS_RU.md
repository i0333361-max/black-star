BLACK STAR RP — статус сборки

Что подготовлено:
- applicationId: com.blackstar.rp
- app_name / hello: Black Star RP
- versionName: 0.1.0-blackstar
- client x64.zip сохранён в корне проекта
- local.properties очищен от чужого абсолютного пути Windows SDK

Результат проверки сборки:
- Gradle 6.1.1 доступен локально, но запуск сборки завершился ошибкой совместимости старого Gradle/Groovy с установленной Java 21 (GroovyBugError / Java7).
- В рабочей среде Android SDK Platform 30 и Build Tools 30.0.1 не обнаружены.
- Сеть из рабочей среды недоступна (DNS не разрешает dl.google.com), поэтому SDK/зависимости нельзя автоматически скачать.
- APK НЕ собран. Этот архив — исходники, не установочный APK.

Для сборки потребуется JDK 8 (либо подходящая Java для Gradle 6.1.1), Android SDK Platform 30, Build Tools 30.0.1, а также доступные Gradle-зависимости. Для изменения/пересборки C++ клиента отдельно потребуется NDK и CMake. Серверные URL в Config.java намеренно пока не менялись.
