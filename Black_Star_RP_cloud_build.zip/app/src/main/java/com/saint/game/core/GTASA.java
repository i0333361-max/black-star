package com.saint.game.core;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import com.wardrumstudios.utils.WarMedia;
import android.util.Log;

public class GTASA extends WarMedia {
    public static GTASA gtasaSelf = null;
    static String vmVersion;
    private boolean once = false;

    static {
        vmVersion = null;
        Log.i("BlackStarRP", "GTASA class initialization: starting native library load");
        try
        {
            vmVersion = System.getProperty("java.vm.version");
            Log.i("BlackStarRP", "Java VM version=" + vmVersion + "; loading ImmEmulatorJ");
            System.loadLibrary("ImmEmulatorJ");
            Log.i("BlackStarRP", "ImmEmulatorJ loaded");
        } catch (ExceptionInInitializerError | UnsatisfiedLinkError e) {
        }

        Log.i("BlackStarRP", "Loading libGTASA.so");
        System.loadLibrary("GTASA");
        Log.i("BlackStarRP", "libGTASA.so loaded; loading libsamp.so");
        System.loadLibrary("samp");
        Log.i("BlackStarRP", "libsamp.so loaded");
    }

    public static void staticEnterSocialClub()
    {
        gtasaSelf.EnterSocialClub();
    }

    public static void staticExitSocialClub() {
        gtasaSelf.ExitSocialClub();
    }

    public void AfterDownloadFunction() {

    }

    public void EnterSocialClub() {

    }

    public void ExitSocialClub() {

    }

    public boolean ServiceAppCommand(String str, String str2)
    {
        return false;
    }

    public int ServiceAppCommandValue(String str, String str2)
    {
        return 0;
    }

    public native void main();

    public void onActivityResult(int i, int i2, Intent intent)
    {
        super.onActivityResult(i, i2, intent);
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    public void onCreate(Bundle bundle)
    {
        if(!once)
        {
            once = true;
        }

        CrashLogger.log(this, "GTASA lifecycle: onCreate entered; native libraries initialized");
        gtasaSelf = this;
        wantsMultitouch = true;
        wantsAccelerometer = true;
        CrashLogger.log(this, "GTASA lifecycle: calling WarMedia.onCreate; next step initializes game base directory and NvUtil");
        super.onCreate(bundle);
        CrashLogger.log(this, "GTASA lifecycle: WarMedia.onCreate returned normally");
    }

    public void onDestroy()
    {
        CrashLogger.log(this, "GTASA lifecycle: onDestroy entered");
        super.onDestroy();
        CrashLogger.log(this, "GTASA lifecycle: onDestroy returned");
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent)
    {
        return super.onKeyDown(i, keyEvent);
    }

    public void onPause()
    {
        CrashLogger.log(this, "GTASA lifecycle: onPause entered");
        super.onPause();
        CrashLogger.log(this, "GTASA lifecycle: onPause returned");
    }

    public void onRestart()
    {
        System.out.println("GTASA onRestart");
        super.onRestart();
    }

    public void onResume()
    {
        CrashLogger.log(this, "GTASA lifecycle: onResume entered");
        super.onResume();
        CrashLogger.log(this, "GTASA lifecycle: onResume returned");
    }

    public void onStart()
    {
        CrashLogger.log(this, "GTASA lifecycle: onStart entered");
        super.onStart();
        CrashLogger.log(this, "GTASA lifecycle: onStart returned");
    }

    public void onStop()
    {
        System.out.println("GTASA onStop");
        super.onStop();
    }

    public native void setCurrentScreenSize(int i, int i2);
}