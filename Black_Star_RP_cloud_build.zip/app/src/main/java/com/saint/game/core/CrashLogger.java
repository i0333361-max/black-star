package com.saint.game.core;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Writes launcher diagnostics into the app-specific external files directory. */
public final class CrashLogger {
    private static final String TAG = "BlackStarRP";
    private CrashLogger() {}
    public static synchronized void log(Context context, String message) {
        Log.i(TAG, message);
        if (context == null) return;
        try {
            File base = context.getExternalFilesDir("diagnostics");
            if (base == null) base = context.getFilesDir();
            if (!base.exists() && !base.mkdirs()) { Log.e(TAG, "Cannot create log directory: " + base); return; }
            File file = new File(base, "launcher-log.txt");
            try (FileOutputStream fos = new FileOutputStream(file, true);
                 OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
                 PrintWriter out = new PrintWriter(osw)) {
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                out.println(time + " " + message);
            }
        } catch (Exception e) { Log.e(TAG, "Failed to write diagnostics", e); }
    }
    public static synchronized void error(Context context, String message, Throwable error) {
        log(context, message + ": " + Log.getStackTraceString(error));
    }
}
