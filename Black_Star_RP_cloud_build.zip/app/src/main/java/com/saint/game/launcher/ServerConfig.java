package com.saint.game.launcher;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Loads the server list from the project's Dropbox-hosted JSON file. */
public final class ServerConfig {
    public static final String SERVERS_URL = "https://www.dropbox.com/scl/fi/1nvaaqw73x541tyouwj8h/Black-Star.json?rlkey=a285indd2fniji14qqefjca64&st=c678oa8p&dl=1";

    public final String name;
    public final String ip;
    public final int port;
    public final String key;

    private ServerConfig(String name, String ip, int port, String key) {
        this.name = name; this.ip = ip; this.port = port; this.key = key;
    }

    public static ServerConfig downloadFirst() throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(SERVERS_URL).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(12000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "application/json");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new Exception("Dropbox вернул HTTP " + status);
            InputStream in = new BufferedInputStream(connection.getInputStream());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            in.close();
            String json = new String(out.toByteArray(), "UTF-8").trim();
            JSONArray servers = new JSONArray(json);
            if (servers.length() == 0) throw new Exception("servers.json не содержит серверов");
            JSONObject server = servers.getJSONObject(0);
            String ip = server.optString("ip", "").trim();
            String portText = server.optString("port", "").trim();
            if (ip.length() == 0 || portText.length() == 0) throw new Exception("В servers.json отсутствует ip или port");
            int port;
            try { port = Integer.parseInt(portText); }
            catch (NumberFormatException e) { throw new Exception("Некорректный port в servers.json"); }
            if (port < 1 || port > 65535) throw new Exception("Порт должен быть от 1 до 65535");
            return new ServerConfig(server.optString("name", "Black Star"), ip, port, server.optString("key", ""));
        } finally {
            connection.disconnect();
        }
    }
}
