package com.saint.game.core;

public class Config {
    public static final String APP_PATH = "storage/emulated/0/Android/data/com.blackstar.rp/files//";
    public static final String GAME_PATH = "/storage/emulated/0/BlackStarRP/";
    public static String PATH_DOWNLOADS = "/storage/emulated/0/Android/data/com.blackstar.rp/files/temp_downloads//";
    public static final String URL_FILES = "https://vk.com/mazan172/game.zip";
    public static final String URL_FILES_UPDATE = "https://vk.com/mazan172/upd.zip";
    public static final String URL_CLIENT = "https://vk.com/mazan172/launcher.apk";
    public static final String URL_DONATE = "http://vk.com/mazan172";
    public static final String GAME_DIR = "/storage/emulated/0/";
}