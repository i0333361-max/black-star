package com.saint.game.launcher;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.saint.game.R;
import com.saint.game.core.Utils;

import org.ini4j.Wini;

import java.io.File;
import java.io.IOException;

import static com.saint.game.core.Config.GAME_PATH;

/** Black Star RP launcher home screen. */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText nickname;
    private Button btnPlay;
    private Button btnSettings;
    private Button btnForum;
    private Button btnVK;

    private static final String PREFS = "black_star_launcher";
    private static final String PREF_NICK = "nickname";
    private static final String SERVER_NAME = "Reb";
    private static final String SERVER_IP = "185.207.214.14";
    private static final int SERVER_PORT = 1753;
    private static final String SERVER_KEY = "1424";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        nickname = findViewById(R.id.nick_main_edit);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        nickname.setText(prefs.getString(PREF_NICK, ""));

        btnPlay = findViewById(R.id.btn_play);
        btnPlay.setOnClickListener(v -> onPlayPressed());

        btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(this);
        btnForum = findViewById(R.id.btnForum);
        btnForum.setOnClickListener(this);
        btnVK = findViewById(R.id.btnVK);
        btnVK.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnSettings) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (id == R.id.btnForum) {
            startActivity(new Intent(this, DonateActivity.class));
        } else if (id == R.id.btnVK) {
            startActivity(new Intent(this, VKActivity.class));
        }
    }

    private void onPlayPressed() {
        String nick = nickname.getText().toString().trim();
        if (nick.isEmpty()) {
            nickname.setError("Сначала введи игровой ник");
            nickname.requestFocus();
            return;
        }
        if (!saveNickname(nick)) {
            Toast.makeText(this, "Не удалось сохранить ник. Проверь доступ к файлам игры.", Toast.LENGTH_LONG).show();
            return;
        }
        if (IsGameInstalled()) {
            StartClient(nick);
        } else {
            StartInstallGame(nick);
        }
    }

    private boolean saveNickname(String nick) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_NICK, nick).apply();
        try {
            File settings = new File(GAME_PATH + "SAMP/settings.ini");
            File parent = settings.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return false;
            if (!settings.exists() && !settings.createNewFile()) return false;
            Wini ini = new Wini(settings);
            ini.put("client", "name", nick);
            ini.store();
            return true;
        } catch (IOException | RuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean IsGameInstalled() {
        return new File(GAME_PATH + "texdb/gta3.img").exists();
    }

    private void StartInstallGame(String nick) {
        Intent intent = new Intent(this, InstallGame.class);
        Utils.setType(0);
        intent.putExtras(getIntent());
        addServerExtras(intent, nick);
        startActivity(intent);
    }

    private void StartClient(String nick) {
        Intent intent = new Intent(this, com.saint.game.core.GTASA.class);
        intent.putExtras(getIntent());
        addServerExtras(intent, nick);
        startActivity(intent);
        finish();
    }

    private void addServerExtras(Intent intent, String nick) {
        intent.putExtra("player_nick", nick);
        intent.putExtra("server_name", SERVER_NAME);
        intent.putExtra("server_ip", SERVER_IP);
        intent.putExtra("server_port", SERVER_PORT);
        intent.putExtra("server_key", SERVER_KEY);
    }
}
