package com.saint.game.launcher;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.saint.game.R;
import com.saint.game.core.Utils;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

import static com.saint.game.core.Config.GAME_PATH;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btn_play;
    private Button btnSettings;
    private Button btnForum;
    private Button btnVK;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean loadingServer = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        btn_play = findViewById(R.id.btn_play);
        btn_play.setOnClickListener(v -> onPlayClicked());
        btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(this);
        btnForum = findViewById(R.id.btnForum);
        btnForum.setOnClickListener(this);
        btnVK = findViewById(R.id.btnVK);
        btnVK.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnSettings) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (v.getId() == R.id.btnForum) {
            startActivity(new Intent(this, DonateActivity.class));
        } else if (v.getId() == R.id.btnVK) {
            startActivity(new Intent(this, VKActivity.class));
        }
    }

    private boolean IsGameInstalled() {
        return new File(GAME_PATH + "texdb/gta3.img").exists();
    }

    private void onPlayClicked() {
        if (!IsGameInstalled()) {
            StartInstallGame();
            return;
        }
        if (loadingServer) return;
        loadingServer = true;
        btn_play.setEnabled(false);
        Toast.makeText(this, "Загружаем список серверов...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                final ServerConfig server = ServerConfig.downloadFirst();
                mainHandler.post(() -> {
                    loadingServer = false;
                    btn_play.setEnabled(true);
                    Toast.makeText(MainActivity.this, "Сервер: " + server.name + " (" + server.ip + ":" + server.port + ")", Toast.LENGTH_SHORT).show();
                    StartClient(server);
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    loadingServer = false;
                    btn_play.setEnabled(true);
                    Toast.makeText(MainActivity.this, "Не удалось загрузить servers.json: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }, "server-json-loader").start();
    }

    private void StartInstallGame() {
        Intent intent = new Intent(this, InstallGame.class);
        Utils.setType(0);
        intent.putExtras(getIntent());
        startActivity(intent);
    }

    private void StartClient(ServerConfig server) {
        Intent intent = new Intent(this, com.saint.game.core.GTASA.class);
        intent.putExtras(getIntent());
        // These extras are the hand-off from the launcher to the game activity.
        intent.putExtra("server_name", server.name);
        intent.putExtra("server_ip", server.ip);
        intent.putExtra("server_port", server.port);
        intent.putExtra("server_key", server.key);
        startActivity(intent);
        finish();
    }
}
