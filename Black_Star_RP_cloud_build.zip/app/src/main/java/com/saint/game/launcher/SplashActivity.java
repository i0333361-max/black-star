package com.saint.game.launcher;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.saint.game.R;
import com.saint.game.core.CrashLogger;
import android.os.Handler;
import android.os.Looper;

/*Project made by vk.com/mazan172 */
public class SplashActivity extends AppCompatActivity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_activity);
        CrashLogger.log(this, "SplashActivity started; SDK=" + Build.VERSION.SDK_INT + ", ABI=" + android.os.Build.SUPPORTED_ABIS[0]);
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                    || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
            } else {
                startTimer();
            }
        } else {
            startTimer();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            CrashLogger.log(this, "Storage permission result granted=" + granted);
            if (granted) startTimer();
            else finish();
        }
    }
    private void startTimer()
    {
        new Handler(Looper.getMainLooper()).postDelayed(this::startLauncher, 2500L);
    }

    private void startLauncher()
    {
        CrashLogger.log(this, "Opening MainActivity");
        startActivity(new Intent(this, com.saint.game.launcher.MainActivity.class));
        finish();
    }
}
